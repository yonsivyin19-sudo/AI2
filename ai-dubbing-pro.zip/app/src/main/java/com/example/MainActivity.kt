package com.example

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.DubViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen()
            }
        }
    }
}

// Colors for Special Cosmic Theme
val SpaceBackgroundFrom = Color(0xFF111625)
val SpaceBackgroundTo = Color(0xFF0C0E17)
val AccentNeonOrange = Color(0xFFFC5A24)
val AccentSkyBlue = Color(0xFF00D2FF)
val CardBackgroundGlass = Color(0xFF1E2538)
val BorderColorGlass = Color(0xFF333E5A)

enum class AppTab {
    STUDIO,
    HISTORY
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainAppScreen(
    viewModel: DubViewModel = viewModel()
) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(AppTab.STUDIO) }

    // State Collection
    val sourceText by viewModel.sourceText.collectAsState()
    val translatedText by viewModel.translatedText.collectAsState()
    val pronunciationGuide by viewModel.pronunciationGuide.collectAsState()
    val expression by viewModel.expression.collectAsState()
    
    val isRecording by viewModel.isRecording.collectAsState()
    val isTranslating by viewModel.isTranslating.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()

    val sourceLanguage by viewModel.sourceLanguage.collectAsState()
    val targetLanguage by viewModel.targetLanguage.collectAsState()

    val audioPitch by viewModel.audioPitch.collectAsState()
    val audioSpeed by viewModel.audioSpeed.collectAsState()

    val selectedMediaName by viewModel.selectedMediaName.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val historyList by viewModel.allProjects.collectAsState()

    // File Selector Launcher (Video or Audio pickup)
    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val name = getFileName(context, uri)
            viewModel.onMediaPicked(uri, name)
            Toast.makeText(context, "Loaded media: $name", Toast.LENGTH_SHORT).show()
        }
    }

    // Mic Permission Request Launcher
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
        if (isGranted) {
            viewModel.startRecordingVoice()
        } else {
            Toast.makeText(context, "Microphone permission required for Speech Recognizer", Toast.LENGTH_LONG).show()
        }
    }

    // Trigger standard system dialog alerts for error states
    LaunchedEffect(errorMessage) {
        if (errorMessage != null) {
            Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show()
            viewModel.clearError()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("app_root_scaffold"),
        containerColor = Color.Transparent,
        bottomBar = {
            // Elegant M3 navigation bar with active pills
            NavigationBar(
                containerColor = SpaceBackgroundTo,
                tonalElevation = 8.dp,
                windowInsets = WindowInsets.navigationBars
            ) {
                NavigationBarItem(
                    selected = activeTab == AppTab.STUDIO,
                    onClick = { activeTab = AppTab.STUDIO },
                    label = { Text("Dubbing Studio") },
                    icon = { Icon(Icons.Default.Mic, contentDescription = "Studio Tab") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = AccentNeonOrange,
                        indicatorColor = AccentNeonOrange,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("tab_studio_button")
                )
                NavigationBarItem(
                    selected = activeTab == AppTab.HISTORY,
                    onClick = { activeTab = AppTab.HISTORY },
                    label = { Text("History History") },
                    icon = { Icon(Icons.Default.History, contentDescription = "History Tab") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = AccentNeonOrange,
                        indicatorColor = AccentNeonOrange,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("tab_history_button")
                )
            }
        }
    ) { innerPadding ->
        // Gradient Atmosphere Background Canvas
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(SpaceBackgroundFrom, SpaceBackgroundTo)
                    )
                )
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // Header layout
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Audiotrack,
                        contentDescription = "App logo",
                        tint = AccentNeonOrange,
                        modifier = Modifier
                            .size(36.dp)
                            .padding(end = 6.dp)
                    )
                    Column {
                        Text(
                            text = "AI DUBBING PRO",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.SansSerif
                        )
                        Text(
                            text = "Acoustic AI Script Alignment & Translation",
                            color = Color.LightGray.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    
                    // Indication of Gemini status
                    AssistChip(
                        onClick = {
                            Toast.makeText(context, "API Key: Checked inside secure Env configuration.", Toast.LENGTH_SHORT).show()
                        },
                        label = {
                            Text(
                                if (viewModel.isRecording.value) "Listening..." else "API Active",
                                color = if (viewModel.isRecording.value) AccentNeonOrange else AccentSkyBlue
                            )
                        },
                        leadingIcon = {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (viewModel.isRecording.value) AccentNeonOrange else AccentSkyBlue)
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = CardBackgroundGlass,
                            labelColor = Color.White
                        ),
                        border = AssistChipDefaults.assistChipBorder(borderColor = BorderColorGlass, enabled = true)
                    )
                }

                Divider(color = BorderColorGlass.copy(alpha = 0.5f), thickness = 1.dp, modifier = Modifier.padding(bottom = 16.dp))

                AnimatedVisibility(
                    visible = activeTab == AppTab.STUDIO,
                    enter = fadeIn() + slideInVertically { -20 },
                    exit = fadeOut() + slideOutVertically { -20 }
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        
                        // Section 1: Lang Pair Picker Cards
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .border(1.dp, BorderColorGlass, RoundedCornerShape(16.dp)),
                            colors = CardDefaults.cardColors(containerColor = CardBackgroundGlass),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Dubbing Channel Setup",
                                    color = AccentSkyBlue,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Source Lang Combo
                                    Box(modifier = Modifier.weight(1f)) {
                                        LanguageSelectorDropdown(
                                            label = "Source Voice Language",
                                            selectedOption = sourceLanguage,
                                            onOptionSelected = { viewModel.setSourceLanguage(it) },
                                            options = viewModel.availableLanguages,
                                            testTag = "source_lang_picker"
                                        )
                                    }

                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = "to direction",
                                        tint = AccentSkyBlue,
                                        modifier = Modifier.padding(horizontal = 8.dp)
                                    )

                                    // Target Lang Combo
                                    Box(modifier = Modifier.weight(1f)) {
                                        LanguageSelectorDropdown(
                                            label = "Target Dubbing Language",
                                            selectedOption = targetLanguage,
                                            onOptionSelected = { viewModel.setTargetLanguage(it) },
                                            options = viewModel.availableLanguages,
                                            testTag = "target_lang_picker"
                                        )
                                    }
                                }
                            }
                        }

                        // Section 2: Input Media Picker & Voice Recording Console
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .border(1.dp, BorderColorGlass, RoundedCornerShape(16.dp)),
                            colors = CardDefaults.cardColors(containerColor = CardBackgroundGlass),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Input Speech / Media Track Selection",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // File Picker Button
                                    Button(
                                        onClick = { mediaPickerLauncher.launch("video/*, audio/*") },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (selectedMediaName != null) AccentSkyBlue else BorderColorGlass
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("select_video_button"),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.VideoFile, contentDescription = "Choose Video", modifier = Modifier.padding(end = 4.dp))
                                        Text(if (selectedMediaName != null) "Change Media" else "Select Video/Audio", fontSize = 12.sp, color = Color.White)
                                    }

                                    // Voice Recording Button
                                    Button(
                                        onClick = {
                                            if (isRecording) {
                                                viewModel.stopRecordingVoice()
                                            } else {
                                                if (hasMicPermission) {
                                                    viewModel.startRecordingVoice()
                                                } else {
                                                    recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isRecording) AccentNeonOrange else Color(0xFF22C55E)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("mic_record_button"),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isRecording) Icons.Default.Square else Icons.Default.Mic,
                                            contentDescription = "Mic Trigger",
                                            modifier = Modifier.padding(end = 4.dp)
                                        )
                                        Text(if (isRecording) "Stop Mic" else "Record Audio", fontSize = 12.sp, color = Color.White)
                                    }
                                }

                                if (selectedMediaName != null) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color.White.copy(alpha = 0.05f))
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Movie, contentDescription = "Active Media", tint = AccentSkyBlue)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = selectedMediaName ?: "",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            maxLines = 1,
                                            modifier = Modifier.weight(1f)
                                        )
                                        IconButton(
                                            onClick = { viewModel.clearMediaPicker() },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear media pick", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }

                                // Interactive Procedural Visual Waveform when Mic is active
                                if (isRecording) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    VoiceWaveformAnimation()
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // Source Speech Output/Edit Card field
                                Text(
                                    text = "Source Transcript Speech",
                                    color = Color.LightGray,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )

                                OutlinedTextField(
                                    value = sourceText,
                                    onValueChange = { viewModel.setSourceText(it) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(110.dp)
                                        .testTag("source_transcript_field"),
                                    placeholder = { Text("Record audio input, pick a vido/audio track, or type original spoken content here...", color = Color.Gray, fontSize = 13.sp) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = AccentSkyBlue,
                                        unfocusedBorderColor = BorderColorGlass,
                                        focusedContainerColor = Color.Black.copy(alpha = 0.2f),
                                        unfocusedContainerColor = Color.Black.copy(alpha = 0.2f),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                // Large central "Translate & AI Dub" Trigger
                                Button(
                                    onClick = { viewModel.performTranslationAndDubbing() },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp)
                                        .testTag("translate_dub_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = AccentNeonOrange),
                                    shape = RoundedCornerShape(12.dp),
                                    enabled = !isTranslating
                                ) {
                                    if (isTranslating) {
                                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text("AI Transcribing & Dubbing...", color = Color.White, fontWeight = FontWeight.Bold)
                                    } else {
                                        Icon(Icons.Default.Psychology, contentDescription = "AI Action")
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("AI TRANSLATE & GENERATE DUB", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                }
                            }
                        }

                        // Section 3: Generated Translation & TTS Studio Output Card
                        AnimatedVisibility(
                            visible = translatedText.isNotEmpty() || isTranslating,
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut()
                        ) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 16.dp)
                                    .border(1.dp, BorderColorGlass, RoundedCornerShape(16.dp)),
                                colors = CardDefaults.cardColors(containerColor = CardBackgroundGlass),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Translated Acoustic Script Output",
                                            color = AccentNeonOrange,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Spacer(modifier = Modifier.weight(1f))
                                        
                                        // Save to History button
                                        IconButton(
                                            onClick = {
                                                viewModel.saveDubbingProject()
                                                Toast.makeText(context, "Saved to Workspace History", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.testTag("save_project_action")
                                        ) {
                                            Icon(Icons.Default.BookmarkAdd, contentDescription = "Bookmark", tint = AccentSkyBlue)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Translated main Text
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color.Black.copy(alpha = 0.3f))
                                            .padding(12.dp)
                                    ) {
                                        Column {
                                            Text(
                                                text = translatedText,
                                                color = Color.White,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                            
                                            if (pronunciationGuide.isNotEmpty()) {
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text(
                                                    text = "Phonetics: $pronunciationGuide",
                                                    color = AccentSkyBlue.copy(alpha = 0.8f),
                                                    fontSize = 13.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }

                                            if (expression.isNotEmpty()) {
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = "Vocal Style: $expression",
                                                    color = Color.LightGray.copy(alpha = 0.7f),
                                                    fontSize = 11.sp,
                                                    fontFamily = FontFamily.SansSerif
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    // Advanced Voice Pitch & Speed adjustments
                                    Text(
                                        text = "Voice Synthesis Calibration",
                                        color = Color.LightGray,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(bottom = 6.dp)
                                    )

                                    // Pitch Slider
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Voice Pitch:", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.width(70.dp))
                                        Slider(
                                            value = audioPitch,
                                            onValueChange = { viewModel.setPitch(it) },
                                            valueRange = 0.5f..2.0f,
                                            modifier = Modifier.weight(1f).testTag("pitch_slider"),
                                            colors = SliderDefaults.colors(
                                                thumbColor = AccentSkyBlue,
                                                activeTrackColor = AccentSkyBlue
                                            )
                                        )
                                        Text(String.format(Locale.US, "%.1fx", audioPitch), color = Color.White, fontSize = 11.sp, modifier = Modifier.width(36.dp), textAlign = TextAlign.End)
                                    }

                                    // Speed Velocity Slider
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Dub Speed:", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.width(70.dp))
                                        Slider(
                                            value = audioSpeed,
                                            onValueChange = { viewModel.setSpeed(it) },
                                            valueRange = 0.5f..2.0f,
                                            modifier = Modifier.weight(1f).testTag("speed_slider"),
                                            colors = SliderDefaults.colors(
                                                thumbColor = AccentNeonOrange,
                                                activeTrackColor = AccentNeonOrange
                                            )
                                        )
                                        Text(String.format(Locale.US, "%.1fx", audioSpeed), color = Color.White, fontSize = 11.sp, modifier = Modifier.width(36.dp), textAlign = TextAlign.End)
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    // TTS Play Aloud Button
                                    Button(
                                        onClick = {
                                            if (isSpeaking) {
                                                viewModel.stopSpeaking()
                                            } else {
                                                viewModel.playDubbedSpeech()
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                            .testTag("play_dub_button"),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isSpeaking) Color.Red else AccentSkyBlue
                                        ),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isSpeaking) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                                            contentDescription = "Acoustic play icon"
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(if (isSpeaking) "STOP VOCALIZATION" else "SPEAK ALOUD / PLAY DUB", fontWeight = FontWeight.Bold, color = Color.White)
                                    }

                                    // Procedural Equalizer indicator if Speak output is active
                                    if (isSpeaking) {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        EqualizerAnimation()
                                    }
                                }
                            }
                        }

                        // App warning for secure keys
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.Yellow.copy(alpha = 0.05f)),
                            border = BorderStroke(1.dp, Color.Yellow.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = "Warning", tint = Color.Yellow, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Security Alert: Stored credentials in .env are only secure for developer prototyping. Avoid distributing live APK copies to prevent unauthorized API calls.",
                                    fontSize = 11.sp,
                                    color = Color.LightGray
                                )
                            }
                        }
                    }
                }

                AnimatedVisibility(
                    visible = activeTab == AppTab.HISTORY,
                    enter = fadeIn() + slideInVertically { 20 },
                    exit = fadeOut() + slideOutVertically { 20 }
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Workspace History Log",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        Text(
                            text = "Restore or inspect previous acoustical dubs",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        if (historyList.isEmpty()) {
                            // Friendly Empty State
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.HourglassEmpty,
                                        contentDescription = "empty list",
                                        tint = Color.Gray.copy(alpha = 0.5f),
                                        modifier = Modifier.size(64.dp)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "No saved projects found.",
                                        color = Color.Gray,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "Translate a speech text in Studio and tap Bookmark to record.",
                                        color = Color.Gray.copy(alpha = 0.7f),
                                        fontSize = 11.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 24.dp)
                                    )
                                }
                            }
                        } else {
                            // Sub-history logger list cards
                            Column {
                                historyList.forEach { project ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(bottom = 10.dp)
                                            .border(1.dp, BorderColorGlass.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                                            .clickable {
                                                viewModel.loadSavedProject(project)
                                                activeTab = AppTab.STUDIO
                                                Toast.makeText(context, "Loaded project into Studio Workspace", Toast.LENGTH_SHORT).show()
                                            }
                                            .testTag("history_item_card_${project.id}"),
                                        colors = CardDefaults.cardColors(containerColor = CardBackgroundGlass),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.Movie, contentDescription = "Media item", tint = AccentNeonOrange, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = project.title,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                
                                                val dateText = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date(project.timestamp))
                                                Text(
                                                    text = dateText,
                                                    color = Color.Gray,
                                                    fontSize = 10.sp
                                                )
                                                
                                                IconButton(
                                                    onClick = { viewModel.deleteProject(project) },
                                                    modifier = Modifier.size(28.dp).testTag("delete_project_${project.id}")
                                                ) {
                                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete project", tint = Color.Red, modifier = Modifier.size(16.dp))
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = "Source (${project.sourceLang}): \"${project.sourceText}\"",
                                                color = Color.LightGray.copy(alpha = 0.8f),
                                                fontSize = 11.sp,
                                                maxLines = 2
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "Target (${project.targetLang}): \"${project.translatedText}\"",
                                                color = AccentSkyBlue,
                                                fontSize = 11.sp,
                                                maxLines = 2
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Dropdown Menu selector for beautiful language items
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageSelectorDropdown(
    label: String,
    selectedOption: DubViewModel.LanguageOption,
    onOptionSelected: (DubViewModel.LanguageOption) -> Unit,
    options: List<DubViewModel.LanguageOption>,
    testTag: String
) {
    var expanded by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(text = label, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color.Black.copy(alpha = 0.2f))
                .border(1.dp, BorderColorGlass, RoundedCornerShape(8.dp))
                .clickable { expanded = true }
                .padding(horizontal = 10.dp, vertical = 10.dp)
                .testTag(testTag),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = selectedOption.displayName, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Icon(
                    imageVector = if (expanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                    contentDescription = "Expand",
                    tint = AccentSkyBlue,
                    modifier = Modifier.size(18.dp)
                )
            }

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier
                    .background(CardBackgroundGlass)
                    .border(1.dp, BorderColorGlass, RoundedCornerShape(8.dp))
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option.displayName, color = Color.White, fontSize = 12.sp) },
                        onClick = {
                            onOptionSelected(option)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}

/**
 * Procedural Dynamic Sinusoidal Waveform Canvas drawing for Recording State visual effects
 */
@Composable
fun VoiceWaveformAnimation() {
    val infiniteTransition = rememberInfiniteTransition(label = "audio_ripple")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * 3.14159f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "waveform_phase"
    )

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.Red.copy(alpha = 0.05f))
    ) {
        val width = size.width
        val height = size.height
        val centerY = height / 2f
        val strokeWidth = 2.dp.toPx()

        val points = mutableListOf<androidx.compose.ui.geometry.Offset>()
        for (x in 0..width.toInt() step 5) {
            val progress = x.toFloat() / width
            // Shape the amplitude as a bell curve at the center, trailing to zero at edges
            val envelope = sin(progress * 3.14159f)
            val amplitude = 18.dp.toPx() * envelope
            val y = centerY + amplitude * sin(progress * 15f + phase)
            points.add(androidx.compose.ui.geometry.Offset(x.toFloat(), y))
        }

        // Draw primary wave
        for (i in 0 until points.size - 1) {
            drawLine(
                color = AccentNeonOrange,
                start = points[i],
                end = points[i + 1],
                strokeWidth = strokeWidth
            )
        }

        // Draw thin secondary background wave out-of-phase
        val baseBackgroundY = centerY
        val secondPoints = mutableListOf<androidx.compose.ui.geometry.Offset>()
        for (x in 0..width.toInt() step 10) {
            val progress = x.toFloat() / width
            val envelope = sin(progress * 3.14159f)
            val amplitude = 10.dp.toPx() * envelope
            val y = baseBackgroundY + amplitude * sin(progress * 8f - phase)
            secondPoints.add(androidx.compose.ui.geometry.Offset(x.toFloat(), y))
        }

        for (i in 0 until secondPoints.size - 1) {
            drawLine(
                color = AccentSkyBlue.copy(alpha = 0.5f),
                start = secondPoints[i],
                end = secondPoints[i + 1],
                strokeWidth = strokeWidth / 2f
            )
        }
    }
}

/**
 * Animated Sound Equalizer playback simulator bar meter
 */
@Composable
fun EqualizerAnimation() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(24.dp)
            .padding(horizontal = 30.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Render 12 animated visualizer vertical rods
        for (i in 0..12) {
            val infiniteTransition = rememberInfiniteTransition(label = "eq_bar_$i")
            val barScale by infiniteTransition.animateFloat(
                initialValue = 0.1f,
                targetValue = 1.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(
                        durationMillis = 300 + (i * 50) % 400,
                        easing = FastOutSlowInEasing
                    ),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "eq_scale_$i"
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(barScale)
                    .clip(RoundedCornerShape(3.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(AccentSkyBlue, AccentNeonOrange)
                        )
                    )
            )
        }
    }
}

/**
 * Helper to parse display filenames from picks
 */
private fun getFileName(context: Context, uri: Uri): String {
    var result: String? = null
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        try {
            if (cursor != null && cursor.moveToFirst()) {
                val columnIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (columnIndex != -1) {
                    result = cursor.getString(columnIndex)
                }
            }
        } finally {
            cursor?.close()
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result?.lastIndexOf('/') ?: -1
        if (cut != -1) {
            result = result?.substring(cut + 1)
        }
    }
    return result ?: "dub_recording.mp4"
}
