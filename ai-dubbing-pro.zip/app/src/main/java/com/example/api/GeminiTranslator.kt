package com.example.api

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Gemini Request / Response models ---

@JsonClass(generateAdapter = true)
data class Part(
    @Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    @Json(name = "parts") val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class ResponseSchema(
    @Json(name = "type") val type: String = "OBJECT",
    @Json(name = "properties") val properties: Map<String, SchemaProperty>? = null,
    @Json(name = "required") val required: List<String>? = null
)

@JsonClass(generateAdapter = true)
data class SchemaProperty(
    @Json(name = "type") val type: String,
    @Json(name = "description") val description: String? = null
)

@JsonClass(generateAdapter = true)
data class ResponseFormat(
    @Json(name = "mimeType") val mimeType: String,
    @Json(name = "responseSchema") val responseSchema: ResponseSchema? = null
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    @Json(name = "responseMimeType") val responseMimeType: String? = null,
    @Json(name = "responseSchema") val responseSchema: ResponseSchema? = null,
    @Json(name = "temperature") val temperature: Float? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    @Json(name = "contents") val contents: List<Content>,
    @Json(name = "generationConfig") val generationConfig: GenerationConfig? = null,
    @Json(name = "systemInstruction") val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class PartResponse(
    @Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class ContentResponse(
    @Json(name = "parts") val parts: List<PartResponse>? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    @Json(name = "content") val content: ContentResponse? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    @Json(name = "candidates") val candidates: List<Candidate>? = null
)

// --- Retrofit Service ---

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

// --- Client Singleton ---

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    val service: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    val jsonParser: Moshi by lazy { moshi }
}

@JsonClass(generateAdapter = true)
data class TranslatorDubResult(
    @Json(name = "translation") val translation: String,
    @Json(name = "pronunciation") val pronunciation: String,
    @Json(name = "expression") val expression: String
)

object GeminiTranslator {
    private const val TAG = "GeminiTranslator"

    // Helper to check if API key is initialized
    fun isApiKeyAvailable(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return key.isNotEmpty() && key != "MY_GEMINI_API_KEY"
    }

    suspend fun translateAndDub(
        text: String,
        sourceLang: String,
        targetLang: String
    ): TranslatorDubResult {
        if (!isApiKeyAvailable()) {
            // Offline fallback simulation
            return getOfflineFallback(text, sourceLang, targetLang)
        }

        val prompt = "Translate the following speech precisely from $sourceLang to $targetLang, focusing on natural performance.\n\nSpeech to translate: \"$text\""

        val systemInstructionText = """
            You are a professional voice dubbing translator.
            Your job is to translate speech naturalistically from a source language to a target language.
            Additionally, provide a phonetic pronunciation guide for the translated text (to aid voice actors), and general audio expression note (like 'Energetic', 'Slightly sad', 'Formal', 'Warm and friendly').
            You must return a valid JSON object matching the requested schema. Do not include markdown codeblocks or wrapper text in your final response.
        """.trimIndent()

        // Configure structured JSON schema response
        val responseSchema = ResponseSchema(
            type = "OBJECT",
            properties = mapOf(
                "translation" to SchemaProperty("STRING", "The translation of the source text in the target language."),
                "pronunciation" to SchemaProperty("STRING", "Phonetic or pronunciation helper guide for pronouncing the translated text."),
                "expression" to SchemaProperty("STRING", "Tone of voice style guide (e.g. Enthusiastic, Warm, Calm, Urgent)")
            ),
            required = listOf("translation", "pronunciation", "expression")
        )

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                responseSchema = responseSchema,
                temperature = 0.3f
            ),
            systemInstruction = Content(parts = listOf(Part(text = systemInstructionText)))
        )

        try {
            val response = GeminiClient.service.generateContent(BuildConfig.GEMINI_API_KEY, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                val adapter = GeminiClient.jsonParser.adapter(TranslatorDubResult::class.java)
                val parsed = adapter.fromJson(jsonText)
                if (parsed != null) {
                    return parsed
                }
            }
            throw Exception("Failed to parse Gemini response: raw content is null or mismatched")
        } catch (e: Exception) {
            Log.e(TAG, "Error in translateAndDub", e)
            return getOfflineFallback(text, sourceLang, targetLang, e.localizedMessage)
        }
    }

    private fun getOfflineFallback(
        text: String,
        sourceLang: String,
        targetLang: String,
        errorMessage: String? = null
    ): TranslatorDubResult {
        // High quality rules-based translations for basic common demo words like "សួស្តី" (Sua s'dei) to English "Hello"
        val lowercaseTxt = text.trim().lowercase()
        val isKmToEn = sourceLang.lowercase().contains("khmer") || sourceLang.lowercase().contains("km")
        
        var translation = "Translated speech here..."
        var pronunciation = "Phonetic Guide..."
        var expression = "Natural tone"

        if (isKmToEn) {
            if (lowercaseTxt == "សួស្តី" || lowercaseTxt.contains("សួស្តី")) {
                translation = "Hello"
                pronunciation = "Heh-loh"
                expression = "Friendly and warm"
            } else if (lowercaseTxt.contains("អរគុណ")) {
                translation = "Thank you"
                pronunciation = "Thangk yoo"
                expression = "Sincere appreciation"
            } else {
                translation = "[Offline fallback] Translate: \"$text\" to English"
                pronunciation = "Text-to-speech phonetic approximation"
                expression = "Clear neutral"
            }
        } else {
            // General support
            if (lowercaseTxt == "hello") {
                translation = "សួស្តី"
                pronunciation = "Sua s'dei"
                expression = "Friendly greeting"
            } else {
                translation = "[Offline mode] Translate: \"$text\" from $sourceLang to $targetLang"
                pronunciation = "Standard vocalized flow"
                expression = "Neutral tone"
            }
        }

        if (errorMessage != null) {
            expression += " (Note: API failed, using fallback)"
        } else {
            expression += " (Offline mode - Setup API key in Secrets panel for high quality AI conversions)"
        }

        return TranslatorDubResult(translation, pronunciation, expression)
    }
}
