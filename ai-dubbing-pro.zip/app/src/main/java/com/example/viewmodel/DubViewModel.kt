package com.example.viewmodel

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiTranslator
import com.example.api.TranslatorDubResult
import com.example.audio.SpeechToTextManager
import com.example.audio.TextToSpeechManager
import com.example.data.DubDatabase
import com.example.data.DubProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DubViewModel(application: Application) : AndroidViewModel(application) {
    private val TAG = "DubViewModel"

    // Raw Room Database Integration
    private val db = DubDatabase.getDatabase(application)
    private val dubProjectDao = db.dubProjectDao()

    val allProjects: StateFlow<List<DubProject>> = dubProjectDao.getAllProjects()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Hardware Managers
    private val sttManager = SpeechToTextManager(application)
    private var ttsManager: TextToSpeechManager? = null

    // Main States
    private val _sourceText = MutableStateFlow("")
    val sourceText: StateFlow<String> = _sourceText.asStateFlow()

    private val _translatedText = MutableStateFlow("")
    val translatedText: StateFlow<String> = _translatedText.asStateFlow()

    private val _pronunciationGuide = MutableStateFlow("")
    val pronunciationGuide: StateFlow<String> = _pronunciationGuide.asStateFlow()

    private val _expression = MutableStateFlow("")
    val expression: StateFlow<String> = _expression.asStateFlow()

    // Screen UI Flags
    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    // Language configuration
    data class LanguageOption(val displayName: String, val languageCode: String, val isSpeechInputSupported: Boolean)

    val availableLanguages = listOf(
        LanguageOption("Khmer (Cambodian)", "km", true),
        LanguageOption("English", "en", true),
        LanguageOption("Spanish", "es", true),
        LanguageOption("French", "fr", true),
        LanguageOption("Japanese", "ja", true),
        LanguageOption("Chinese", "zh", true),
        LanguageOption("Vietnamese", "vi", true),
        LanguageOption("Thai", "th", true)
    )

    private val _sourceLanguage = MutableStateFlow(availableLanguages[0]) // Default Khmer
    val sourceLanguage: StateFlow<LanguageOption> = _sourceLanguage.asStateFlow()

    private val _targetLanguage = MutableStateFlow(availableLanguages[1]) // Default English
    val targetLanguage: StateFlow<LanguageOption> = _targetLanguage.asStateFlow()

    // Synth adjustment states
    private val _audioPitch = MutableStateFlow(1.0f)
    val audioPitch: StateFlow<Float> = _audioPitch.asStateFlow()

    private val _audioSpeed = MutableStateFlow(1.0f)
    val audioSpeed: StateFlow<Float> = _audioSpeed.asStateFlow()

    // File selector simulated state
    private val _selectedMediaName = MutableStateFlow<String?>(null)
    val selectedMediaName: StateFlow<String?> = _selectedMediaName.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    init {
        ttsManager = TextToSpeechManager(application) { success ->
            if (!success) {
                _errorMessage.value = "Local Speech Synthesis Engine failed initialization. Check device settings."
            }
        }
    }

    fun setSourceText(text: String) {
        _sourceText.value = text
    }

    fun setSourceLanguage(lang: LanguageOption) {
        _sourceLanguage.value = lang
    }

    fun setTargetLanguage(lang: LanguageOption) {
        _targetLanguage.value = lang
    }

    fun setPitch(pitch: Float) {
        _audioPitch.value = pitch
    }

    fun setSpeed(speed: Float) {
        _audioSpeed.value = speed
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun onMediaPicked(uri: Uri, fileName: String) {
        _selectedMediaName.value = fileName
        _sourceText.value = "" // Reset on new pick
        _errorMessage.value = null
        
        // Auto-transcribe video mock-demonstrator
        viewModelScope.launch {
            _isTranslating.value = true
            kotlinx.coroutines.delay(1200) // Aesthetic delay for progress indicators
            
            // Generate simulated audio transcript from Selected Video or Audio
            val isVideo = fileName.substringAfterLast(".").lowercase() in listOf("mp4", "mkv", "avi", "mov", "3gp")
            val mediaType = if (isVideo) "video" else "audio"

            val simulatedText = when (_sourceLanguage.value.languageCode) {
                "km" -> "សួស្តី អរគុណសម្រាប់ការទស្សនាវីដេអូនេះ។"
                "es" -> "Hola, bienvenidos a este genial video de doblaje."
                "fr" -> "Bonjour, merci d'avoir regardé notre vidéo."
                "ja" -> "こんにちは、AI吹き替えプロへようこそ。"
                "zh" -> "你好，欢迎观看这个 AI 视频配音。"
                else -> "Welcome to AI Dubbing Pro. Let's create an amazing translation."
            }
            
            _sourceText.value = simulatedText
            _isTranslating.value = false
            Log.d(TAG, "Simulated media picker read: $simulatedText from $mediaType")
        }
    }

    fun clearMediaPicker() {
        _selectedMediaName.value = null
    }

    /**
     * Start recording live speech via microphone
     */
    fun startRecordingVoice() {
        if (_isRecording.value) return
        _errorMessage.value = null
        _isRecording.value = true
        _sourceText.value = "Listening..."

        sttManager.startListening(
            languageCode = _sourceLanguage.value.languageCode,
            onReady = {
                _sourceText.value = "Speak now..."
            },
            onResult = { result ->
                _sourceText.value = result
                _isRecording.value = false
            },
            onError = { error ->
                _errorMessage.value = "Speech recognition error: $error"
                _isRecording.value = false
                if (_sourceText.value == "Listening..." || _sourceText.value == "Speak now...") {
                    _sourceText.value = ""
                }
            },
            onPartialResult = { partial ->
                _sourceText.value = partial
            }
        )
    }

    fun stopRecordingVoice() {
        if (!_isRecording.value) return
        sttManager.stopListening()
        _isRecording.value = false
    }

    /**
     * Translate source text using Gemini structured JSON response, or rules fallback.
     */
    fun performTranslationAndDubbing() {
        val input = _sourceText.value.trim()
        if (input.isEmpty() || input == "Listening..." || input == "Speak now...") {
            _errorMessage.value = "Please enter or record some text to dub first."
            return
        }

        _errorMessage.value = null
        _isTranslating.value = true

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = GeminiTranslator.translateAndDub(
                    text = input,
                    sourceLang = _sourceLanguage.value.displayName,
                    targetLang = _targetLanguage.value.displayName
                )
                
                _translatedText.value = result.translation
                _pronunciationGuide.value = result.pronunciation
                _expression.value = result.expression
            } catch (e: Exception) {
                Log.e(TAG, "Error in performing translation", e)
                _errorMessage.value = e.localizedMessage ?: "Translation failed."
            } finally {
                _isTranslating.value = false
            }
        }
    }

    /**
     * Speak translated results aloud using local TTS
     */
    fun playDubbedSpeech() {
        val text = _translatedText.value.trim()
        if (text.isEmpty()) {
            _errorMessage.value = "No translated speech to vocalize. Please translate first."
            return
        }

        _isSpeaking.value = true
        ttsManager?.speak(
            text = text,
            targetLanguageCode = _targetLanguage.value.languageCode,
            pitch = _audioPitch.value,
            speed = _audioSpeed.value,
            onStart = {
                _isSpeaking.value = true
            },
            onDone = {
                _isSpeaking.value = false
            }
        )
    }

    fun stopSpeaking() {
        ttsManager?.stop()
        _isSpeaking.value = false
    }

    /**
     * Save current dubbing profile project to history
     */
    fun saveDubbingProject(customTitle: String = "") {
        val src = _sourceText.value.trim()
        val trans = _translatedText.value.trim()
        if (src.isEmpty() || trans.isEmpty()) {
            _errorMessage.value = "Please record and translate before saving project."
            return
        }

        val projectTitle = if (customTitle.trim().isNotEmpty()) {
            customTitle
        } else {
            "Dub - ${_sourceLanguage.value.displayName} to ${_targetLanguage.value.displayName}"
        }

        viewModelScope.launch(Dispatchers.IO) {
            val dbProject = DubProject(
                title = projectTitle,
                timestamp = System.currentTimeMillis(),
                sourceText = src,
                translatedText = trans,
                sourceLang = _sourceLanguage.value.displayName,
                targetLang = _targetLanguage.value.displayName,
                voiceName = "Default Synth Accent",
                pronunciationGuide = _pronunciationGuide.value,
                audioSpeed = _audioSpeed.value,
                audioPitch = _audioPitch.value
            )
            dubProjectDao.insertProject(dbProject)
            Log.d(TAG, "Successfully recorded project to history.")
        }
    }

    fun loadSavedProject(project: DubProject) {
        _sourceText.value = project.sourceText
        _translatedText.value = project.translatedText
        _pronunciationGuide.value = project.pronunciationGuide
        _audioSpeed.value = project.audioSpeed
        _audioPitch.value = project.audioPitch
        
        // Map language options
        val srcOpt = availableLanguages.firstOrNull { it.displayName == project.sourceLang }
        val tgtOpt = availableLanguages.firstOrNull { it.displayName == project.targetLang }
        if (srcOpt != null) _sourceLanguage.value = srcOpt
        if (tgtOpt != null) _targetLanguage.value = tgtOpt

        _errorMessage.value = null
        _selectedMediaName.value = null // Clear file selection reference
    }

    fun deleteProject(project: DubProject) {
        viewModelScope.launch(Dispatchers.IO) {
            dubProjectDao.deleteProject(project)
        }
    }

    override fun onCleared() {
        super.onCleared()
        sttManager.destroy()
        ttsManager?.destroy()
    }
}
