package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "dub_projects")
data class DubProject(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo(name = "title") val title: String,
    @ColumnInfo(name = "timestamp") val timestamp: Long,
    @ColumnInfo(name = "source_text") val sourceText: String,
    @ColumnInfo(name = "translated_text") val translatedText: String,
    @ColumnInfo(name = "source_lang") val sourceLang: String,
    @ColumnInfo(name = "target_lang") val targetLang: String,
    @ColumnInfo(name = "voice_name") val voiceName: String,
    @ColumnInfo(name = "pronunciation_guide") val pronunciationGuide: String = "",
    @ColumnInfo(name = "audio_speed") val audioSpeed: Float = 1.0f,
    @ColumnInfo(name = "audio_pitch") val audioPitch: Float = 1.0f
)

@Dao
interface DubProjectDao {
    @Query("SELECT * FROM dub_projects ORDER BY timestamp DESC")
    fun getAllProjects(): Flow<List<DubProject>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: DubProject): Long

    @Delete
    suspend fun deleteProject(project: DubProject)
}

@Database(entities = [DubProject::class], version = 1, exportSchema = false)
abstract class DubDatabase : RoomDatabase() {
    abstract fun dubProjectDao(): DubProjectDao

    companion object {
        @Volatile
        private var INSTANCE: DubDatabase? = null

        fun getDatabase(context: Context): DubDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DubDatabase::class.java,
                    "dub_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
