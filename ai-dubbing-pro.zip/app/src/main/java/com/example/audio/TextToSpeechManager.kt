package com.example.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class TextToSpeechManager(context: Context, private val onInitCompleted: (Boolean) -> Unit = {}) {
    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private val TAG = "TextToSpeechManager"

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                Log.d(TAG, "TTS engine successfully initialized")
                // Try choosing English by default initially as safe fallback
                tts?.language = Locale.US
                onInitCompleted(true)
            } else {
                isInitialized = false
                Log.e(TAG, "TTS initialization failed: status=$status")
                onInitCompleted(false)
            }
        }
    }

    /**
     * Speak the provided text in the target language code, applying pitch and speed modifiers.
     */
    fun speak(
        text: String,
        targetLanguageCode: String,
        pitch: Float = 1.0f,
        speed: Float = 1.0f,
        onStart: () -> Unit = {},
        onDone: () -> Unit = {}
    ) {
        if (!isInitialized || tts == null) {
            Log.e(TAG, "TTS speak failed: Engine not ready")
            return
        }

        val locale = getLocaleFromCode(targetLanguageCode)
        val languageResult = tts?.setLanguage(locale)
        if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            Log.w(TAG, "TTS language is not fully supported locally: $targetLanguageCode, falling back to default locale")
            tts?.language = Locale.getDefault()
        }

        // Apply pitch & speed
        tts?.setPitch(pitch)
        tts?.setSpeechRate(speed)

        // Set TTS Event Listeners if required (modern listener syntax)
        tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                onStart()
            }

            override fun onDone(utteranceId: String?) {
                onDone()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                onDone()
            }
        })

        // Speak aloud
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "DubbingSpeechId")
    }

    /**
     * Stop currently playing utterance.
     */
    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            Log.e(TAG, "Failed stop", e)
        }
    }

    /**
     * Terminate the TTS engine.
     */
    fun destroy() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
            isInitialized = false
        } catch (e: Exception) {
            Log.e(TAG, "Failed destroy", e)
        }
    }

    private fun getLocaleFromCode(code: String): Locale {
        return when (code.lowercase()) {
            "km", "khm", "khmer" -> Locale("km", "KH")
            "en", "eng", "english" -> Locale.US
            "es", "spa", "spanish" -> Locale("es", "ES")
            "fr", "fra", "french" -> Locale.FRANCE
            "zh", "zho", "chinese" -> Locale.CHINESE
            "ja", "jpn", "japanese" -> Locale.JAPAN
            "ko", "kor", "korean" -> Locale.KOREA
            "de", "deu", "german" -> Locale.GERMAN
            "it", "ita", "italian" -> Locale.ITALY
            "vi", "vie", "vietnamese" -> Locale("vi", "VN")
            "th", "tha", "thai" -> Locale("th", "TH")
            else -> {
                // Try converting standard ISO-639 codes
                if (code.length >= 2) {
                    val codeSlice = code.substring(0, 2)
                    Locale(codeSlice)
                } else {
                    Locale.getDefault()
                }
            }
        }
    }
}
